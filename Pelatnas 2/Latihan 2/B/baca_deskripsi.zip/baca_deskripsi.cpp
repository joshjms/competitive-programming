#include "baca_deskripsi.h"

vector<int> getAnswers(int n, int m, vector<int> A, vector<int> B){
	vector<int> ret = {69, 420};
	
	return ret;
} 
