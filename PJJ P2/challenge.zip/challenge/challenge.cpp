#include "challenge.h"

#include <vector>

void initialize(int N, std::vector<int> A) {
}

int solve_challenge(int x, int t) {
  return -1;
}
