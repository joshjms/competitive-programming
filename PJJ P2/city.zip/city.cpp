#include <algorithm>
#include <vector>
#include "city.h"

std::pair<int, int> getBestXY(int N, int M, int S, int T, std::vector<int> A, std::vector<int> B, std::vector<int> C) {
  std::pair<int, int> result = {0, N-1};
  return result;
}